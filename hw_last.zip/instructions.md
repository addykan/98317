1. Go to https://agdapad.quasicoherent.io/
2. Click the big, purple `New Agda Session` button
3. Select everything in the file, and delete it
4. Click the little purple clipboard button in the bottom right
5. Paste the provided starter code into the pink box that pops up
6. Click the `Dismiss` button at the bottom right of the pink box
7. Click the `Edit` dropdown menu, and select `Paste`
8. Follow the instructions in the starter code
9. When you're done, click the clipboard button again, click `Download files`, and click the `hello.agda` file
10. Submit this file to Gradescope
